# Waynovo Universal v3.0

Painel universal de apoio ao estudo, com bookmarklet e versão para gerenciador de userscripts.

## Novidades

- Interface redesenhada, com tema escuro, hierarquia visual e painel recolhível.
- Layout responsivo para celular, com áreas de toque maiores e respeito às safe areas.
- Shadow DOM para reduzir conflitos com CSS da página hospedeira.
- Captura do texto selecionado, inclusive seleção inicial ao abrir o painel.
- Captura do texto renderizado/visível da página (limitada a 22 mil caracteres por captura).
- Possibilidade de reunir trechos e anotações no mesmo material.
- Sete modos: tutor, simulado de prática, resumo, flashcards, revisão de tentativa, extração de conceitos e plano de estudo.
- Geração de prompt, cópia e exportação em `.txt`.
- Sem bibliotecas externas, chaves de API, requisições de rede ou armazenamento do conteúdo.

## Instalação como bookmarklet

1. Abra o arquivo `waynovo-bookmarklet.js` e copie a linha inteira, começando por `javascript:`.
2. Crie um favorito no navegador com o nome `Waynovo`.
3. Edite o endereço/URL desse favorito e cole o conteúdo copiado.
4. Em qualquer página HTTPS ou HTTP que permita bookmarklets, toque/clique no favorito para abrir o painel.

Em celulares, o suporte a bookmarklets depende do navegador. Alguns navegadores móveis bloqueiam a execução de favoritos JavaScript. Nesse caso, use um gerenciador de userscripts compatível com seu navegador.

## Instalação via Tampermonkey/Violentmonkey ou equivalente

1. Abra o gerenciador de userscripts.
2. Crie um script novo.
3. Substitua o conteúdo pelo arquivo `waynovo-universal.user.js` e salve.
4. Atualize a página. O painel será injetado em páginas HTTP/HTTPS.

O gerenciador pode exigir permissões próprias e nem todos os navegadores móveis oferecem suporte a extensões/userscripts.

## Uso rápido

- **Capturar seleção:** selecione um trecho da página e toque no botão.
- **Texto visível da página:** reúne o texto renderizado da página atual, respeitando o limite para manter a saída administrável.
- **Gerar pacote:** escolha um dos modos e gere o prompt.
- **Copiar prompt** ou **Baixar .txt:** leve o pacote para a IA de sua preferência.
- **Reunir material:** repita a captura de trechos; o painel acrescenta cada trecho ao material existente.

## Limites técnicos e privacidade

- “Universal” significa que o painel não depende de seletores específicos de um site e pode ser executado em muitas páginas HTTP/HTTPS. Nenhum bookmarklet pode ser garantido em absolutamente todos os sites: políticas de segurança, páginas especiais do navegador, iframes isolados e restrições do próprio navegador podem impedir a execução.
- A captura de página lê apenas `innerText`/texto renderizado do documento atual; não lê variáveis internas da aplicação, chamadas de rede, bancos de dados, conteúdo oculto nem páginas cross-origin dentro de iframes.
- O Waynovo não tenta ocultar sua execução, falsificar identidade do navegador, contornar detecção, CAPTCHA ou controles de acesso. Também não seleciona alternativas nem envia respostas em avaliações ativas.
- Não há chamadas a servidores. O prompt só sai do navegador quando você decide copiá-lo, baixá-lo ou colá-lo em outro serviço.
- O painel não guarda o material após fechar ou recarregar a página.
