// ==UserScript==
// @name         Waynovo Universal Study Panel
// @namespace    waynovo
// @version      3.0.0
// @description  Painel universal e responsivo para captura e organização de material de estudo.
// @match        *://*/*
// @run-at       document-idle
// @grant        none
// @noframes
// ==/UserScript==

(() => {
  'use strict';

  const HOST_ID = 'waynovo-universal-host';
  if (document.getElementById(HOST_ID)) return;

  const host = document.createElement('div');
  host.id = HOST_ID;
  host.setAttribute('aria-label', 'Painel Waynovo');
  host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
  (document.documentElement || document.body).appendChild(host);
  const shadow = host.attachShadow({ mode: 'open' });

  const css = `
    :host { all: initial; color-scheme: dark; }
    * { box-sizing: border-box; }
    .wn-panel {
      --bg:#0b1020; --surface:#111a2e; --surface2:#17233b; --line:#283650;
      --text:#eef4ff; --muted:#9cabc4; --accent:#8b7cff; --accent2:#38c8b4;
      position:fixed; right:22px; bottom:22px; width:min(460px,calc(100vw - 28px));
      max-height:min(820px,calc(100dvh - 44px)); display:flex; flex-direction:column;
      overflow:hidden; pointer-events:auto; color:var(--text); background:var(--bg);
      border:1px solid rgba(151,166,204,.25); border-radius:22px;
      box-shadow:0 24px 80px rgba(0,0,0,.48),0 2px 12px rgba(0,0,0,.2);
      font:14px/1.45 Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
      isolation:isolate;
    }
    .wn-panel * { box-sizing:border-box; }
    .wn-top { display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 17px;
      background:radial-gradient(120% 150% at 0% 0%,rgba(139,124,255,.26),transparent 62%),linear-gradient(120deg,#17233b,#10182b);
      border-bottom:1px solid var(--line); cursor:grab; user-select:none; touch-action:pan-y; }
    .wn-brand { display:flex;align-items:center;gap:11px;min-width:0; }
    .wn-logo { width:38px;height:38px;display:grid;place-items:center;border-radius:13px;
      color:white;font-size:20px;font-weight:900;background:linear-gradient(145deg,#9a86ff,#5e56d9);
      box-shadow:0 7px 24px rgba(126,104,255,.35); }
    .wn-name { font-weight:850;font-size:15px;letter-spacing:.2px; }
    .wn-sub { font-size:11px;color:#abb9d5;margin-top:1px; }
    .wn-tag { font-size:9px;letter-spacing:.8px;text-transform:uppercase;color:#b8f4e8;
      background:rgba(56,200,180,.12);border:1px solid rgba(56,200,180,.25);padding:4px 7px;border-radius:20px;margin-left:5px; }
    .wn-top-actions { display:flex;gap:6px;flex-shrink:0; }
    button { font:inherit; }
    .wn-icon { width:32px;height:32px;border-radius:10px;display:grid;place-items:center;color:#dce5fb;
      background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.08);cursor:pointer;font-size:17px; }
    .wn-icon:hover { background:rgba(255,255,255,.14); }
    .wn-content { padding:15px;overflow:auto;overscroll-behavior:contain;display:grid;gap:12px; }
    .wn-intro { display:flex;align-items:flex-start;gap:9px;padding:11px 12px;border:1px solid rgba(139,124,255,.19);
      border-radius:13px;background:rgba(139,124,255,.075);color:#c5cde4;font-size:11px; }
    .wn-intro b { color:#edeaff; }
    .wn-field { display:grid;gap:6px;min-width:0; }
    .wn-label { color:#bec9df;font-size:11px;font-weight:750;letter-spacing:.35px;display:flex;justify-content:space-between;gap:8px; }
    .wn-count { color:#7889a7;font-weight:500; }
    textarea,input,select { width:100%;min-width:0;border:1px solid var(--line);border-radius:12px;background:#0e1729;
      color:var(--text);padding:11px 12px;font:13px/1.5 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;outline:none; }
    textarea { min-height:148px;resize:vertical; }
    textarea:focus,input:focus,select:focus { border-color:#8072f5;box-shadow:0 0 0 3px rgba(139,124,255,.13); }
    input::placeholder,textarea::placeholder { color:#6f7f9b; }
    select { appearance:auto; }
    .wn-row { display:flex;gap:8px; }
    .wn-row > * { flex:1;min-width:0; }
    .wn-btn { min-height:40px;border-radius:12px;border:1px solid transparent;padding:9px 12px;cursor:pointer;
      font-weight:760;font-size:12px;transition:transform .12s ease,filter .12s ease; }
    .wn-btn:active { transform:scale(.985); }
    .wn-primary { color:#fff;background:linear-gradient(120deg,#8174f2,#6255d9);box-shadow:0 6px 18px rgba(105,89,220,.2); }
    .wn-secondary { background:var(--surface2);border-color:var(--line);color:#e4eaf8; }
    .wn-soft { background:transparent;border-color:var(--line);color:#bfcce3; }
    .wn-btn:hover { filter:brightness(1.1); }
    .wn-tools { display:grid;grid-template-columns:repeat(3,1fr);gap:7px; }
    .wn-tool { min-height:62px;padding:9px 7px;border-radius:12px;border:1px solid var(--line);background:var(--surface);
      color:#dbe4f6;text-align:left;cursor:pointer;display:flex;flex-direction:column;gap:5px; }
    .wn-tool strong { font-size:11px; }
    .wn-tool span { font-size:10px;color:#8798b7; }
    .wn-tool:hover { border-color:#665bd1;background:#171f39; }
    .wn-status { min-height:17px;color:#99e5d7;font-size:11px; }
    .wn-result { display:grid;gap:8px;padding-top:10px;border-top:1px solid var(--line); }
    .wn-result textarea { min-height:190px;background:#0a1323; }
    .wn-foot { padding:10px 15px 13px;border-top:1px solid rgba(40,54,80,.7);display:flex;justify-content:space-between;gap:12px;
      color:#7586a3;font-size:10px;background:#0b1120; }
    .wn-foot span:last-child { text-align:right; }
    .wn-hidden { display:none !important; }
    .wn-panel.wn-min { width:250px;max-height:74px;border-radius:18px; }
    .wn-panel.wn-min .wn-content,.wn-panel.wn-min .wn-foot { display:none; }
    .wn-panel.wn-min .wn-top { border:0; }
    @media (max-width:640px) {
      .wn-panel { inset: max(7px,env(safe-area-inset-top)) max(7px,env(safe-area-inset-right)) max(7px,env(safe-area-inset-bottom)) max(7px,env(safe-area-inset-left));
        width:auto;max-height:none;height:auto;border-radius:20px; }
      .wn-top { padding:13px 13px;cursor:default; }
      .wn-content { padding:12px;gap:10px; }
      textarea { min-height:132px;font-size:16px; }
      input,select { min-height:44px;font-size:16px; }
      .wn-btn { min-height:44px;font-size:13px; }
      .wn-tools { grid-template-columns:repeat(2,1fr); }
      .wn-tool { min-height:58px; }
      .wn-foot { padding-bottom:max(12px,env(safe-area-inset-bottom)); }
      .wn-panel.wn-min { inset:auto 12px max(12px,env(safe-area-inset-bottom)) auto;width:220px;height:auto;max-height:74px; }
    }
    @media (prefers-reduced-motion:reduce) { .wn-btn { transition:none; } }
  `;
  const style = document.createElement('style');
  style.textContent = css;
  shadow.appendChild(style);

  const initialSelection = String(window.getSelection?.() || '').trim();
  const panel = document.createElement('section');
  panel.className = 'wn-panel';
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', 'Waynovo — painel universal de estudos');
  panel.innerHTML = `
    <header class="wn-top" id="wn-drag">
      <div class="wn-brand"><div class="wn-logo">W</div><div><div class="wn-name">Waynovo <span class="wn-tag">Universal</span></div><div class="wn-sub">Central de aprendizagem</div></div></div>
      <div class="wn-top-actions"><button class="wn-icon" id="wn-min" aria-label="Minimizar" title="Minimizar">–</button><button class="wn-icon" id="wn-close" aria-label="Fechar" title="Fechar">×</button></div>
    </header>
    <main class="wn-content">
      <div class="wn-intro"><span>✦</span><div><b>Seu material, pronto para estudar.</b><br>Capture um trecho, reúna o texto visível da página ou cole suas próprias anotações.</div></div>
      <div class="wn-field"><label class="wn-label" for="wn-source">MATERIAL DE ESTUDO <span class="wn-count" id="wn-count">0 caracteres</span></label>
        <textarea id="wn-source" placeholder="Selecione um trecho da página e use Capturar seleção, ou cole seu material aqui…"></textarea></div>
      <div class="wn-row"><button class="wn-btn wn-secondary" id="wn-selection">↳ Capturar seleção</button><button class="wn-btn wn-secondary" id="wn-page">▤ Texto visível da página</button></div>
      <div class="wn-field"><label class="wn-label" for="wn-goal">OBJETIVO (OPCIONAL)</label><input id="wn-goal" placeholder="Ex.: preparar uma revisão de biologia" maxlength="240"></div>
      <div class="wn-field"><label class="wn-label" for="wn-mode">MODO DE AUTOMAÇÃO</label><select id="wn-mode">
        <option value="tutor">Tutor passo a passo</option><option value="practice">Simulado de prática</option><option value="summary">Resumo estruturado</option>
        <option value="cards">Flashcards automáticos</option><option value="review">Revisar minha tentativa</option>
        <option value="extract">Extrair conceitos e definições</option><option value="plan">Plano de estudo</option>
      </select></div>
      <div class="wn-field wn-hidden" id="wn-attempt-wrap"><label class="wn-label" for="wn-attempt">SUA TENTATIVA</label><textarea id="wn-attempt" placeholder="Cole ou escreva sua resposta para receber uma revisão…" style="min-height:78px"></textarea></div>
      <div class="wn-tools">
        <button class="wn-tool" id="wn-fast-tutor"><strong>✧ Explicar</strong><span>Entender o conteúdo</span></button>
        <button class="wn-tool" id="wn-fast-practice"><strong>◈ Praticar</strong><span>Gerar questões</span></button>
        <button class="wn-tool" id="wn-fast-cards"><strong>▣ Memorizar</strong><span>Criar flashcards</span></button>
      </div>
      <button class="wn-btn wn-primary" id="wn-generate">Gerar pacote de estudo <span aria-hidden="true">→</span></button>
      <div class="wn-status" id="wn-status" role="status" aria-live="polite"></div>
      <section class="wn-result wn-hidden" id="wn-result">
        <label class="wn-label" for="wn-output">PROMPT GERADO</label>
        <textarea id="wn-output" readonly spellcheck="false"></textarea>
        <div class="wn-row"><button class="wn-btn wn-primary" id="wn-copy">Copiar prompt</button><button class="wn-btn wn-secondary" id="wn-download">Baixar .txt</button></div>
      </section>
      <div class="wn-row"><button class="wn-btn wn-soft" id="wn-clear">Limpar conteúdo</button><button class="wn-btn wn-soft" id="wn-close-bottom">Fechar painel</button></div>
    </main>
    <footer class="wn-foot"><span>Sem chaves ou envio automático</span><span>v3.0 · seus dados ficam nesta página</span></footer>
  `;
  shadow.appendChild(panel);

  const $ = (selector) => shadow.querySelector(selector);
  const source = $('#wn-source');
  const status = $('#wn-status');
  const count = $('#wn-count');
  const result = $('#wn-result');
  const output = $('#wn-output');
  let lastPrompt = '';

  function say(message) { status.textContent = message; }
  function updateCount() { count.textContent = `${source.value.length.toLocaleString('pt-BR')} caracteres`; }
  function appendMaterial(text, label) {
    const clean = String(text || '').replace(/\u0000/g, '').trim();
    if (!clean) { say('Nenhum texto disponível para capturar.'); return; }
    const existing = source.value.trim();
    if (existing && existing.includes(clean)) { say('Esse trecho já está no material.'); return; }
    source.value = existing ? `${existing}\n\n--- ${label} ---\n${clean}` : clean;
    updateCount();
    say(`${clean.length.toLocaleString('pt-BR')} caracteres adicionados.`);
  }
  function captureSelection() {
    const selected = String(window.getSelection?.() || '').trim() || initialSelection;
    if (!selected) { say('Selecione um texto na página e tente novamente.'); return; }
    appendMaterial(selected, 'Trecho selecionado');
  }
  function captureVisiblePage() {
    // Usa apenas texto renderizado/visível; não consulta estados internos, APIs ou dados ocultos.
    let text = '';
    try { text = (document.body?.innerText || document.documentElement?.innerText || '').trim(); }
    catch (error) { say('Esta página não permite ler o texto visível. Cole o material manualmente.'); return; }
    text = text.replace(/\n{3,}/g, '\n\n');
    const limit = 22000;
    if (!text) { say('Não encontrei texto visível nesta página.'); return; }
    const clipped = text.length > limit ? text.slice(0, limit) : text;
    appendMaterial(clipped, 'Texto visível da página');
    if (text.length > limit) say(`Texto capturado até ${limit.toLocaleString('pt-BR')} caracteres para manter o prompt utilizável.`);
  }

  const tasks = {
    tutor: 'Atue como tutor. Explique o material em etapas progressivas: visão geral, conceitos essenciais, explicação em linguagem clara, exemplos originais e erros comuns. Termine com 3 perguntas de checagem, sem presumir que o estudante já domina o tema.',
    practice: 'Crie um simulado de prática com 8 questões progressivas e variadas, usando somente o material como base. Apresente uma questão por vez e aguarde minha tentativa antes de revelar o gabarito. Após cada tentativa, dê feedback e explique o raciocínio.',
    summary: 'Crie um resumo estruturado com: ideia central, tópicos principais, conceitos e definições, relações de causa e efeito, exemplos citados e uma seção final de revisão rápida. Não omita ressalvas importantes do material.',
    cards: 'Gere até 15 flashcards objetivos em formato Pergunta | Resposta. Cubra os conceitos mais importantes, evite duplicatas e mantenha cada resposta curta. Ao final, inclua uma lista dos cartões que exigem mais compreensão, não apenas memorização.',
    review: 'Revise a tentativa do estudante com uma rubrica clara. Separe o que está correto, o que está incompleto, o que precisa ser corrigido e como melhorar. Explique o raciocínio e proponha uma nova questão de prática. Não dê nota sem critérios explícitos.',
    extract: 'Extraia os conceitos-chave, definições, nomes, datas, fórmulas e relações que aparecem explicitamente no material. Organize em tabela. Quando um dado não estiver presente, escreva “não informado no material”; não complete lacunas por suposição.',
    plan: 'Monte um plano de estudo prático em 5 sessões curtas. Para cada sessão, indique objetivo, conteúdo, atividade ativa de recuperação e um critério simples para verificar compreensão. Distribua os tópicos do material de forma progressiva.'
  };

  function buildPrompt() {
    const material = source.value.trim();
    if (!material) { say('Adicione material usando a captura ou cole um texto primeiro.'); source.focus(); return; }
    if (material.length > 30000) { say('O material passou de 30 mil caracteres. Divida em partes para obter resultados melhores.'); return; }
    const mode = $('#wn-mode').value;
    if (mode === 'review' && !$('#wn-attempt').value.trim()) { say('Inclua sua tentativa para usar o modo de revisão.'); $('#wn-attempt').focus(); return; }
    const goal = $('#wn-goal').value.trim();
    const attempt = $('#wn-attempt').value.trim();
    const sections = [
      'Você é o Waynovo, um assistente de aprendizagem claro, rigoroso e colaborativo.',
      'OBJETIVO: ajudar o estudante a aprender, praticar e revisar; não invente fatos nem atribua ao material informações que ele não contém.',
      goal ? `OBJETIVO ESPECÍFICO DO ESTUDANTE:\n${goal}` : '',
      `TAREFA:\n${tasks[mode]}`,
      'REGRAS DE QUALIDADE:\n- Trate o material fornecido como fonte principal.\n- Diferencie claramente conteúdo da fonte e conhecimento complementar.\n- Se houver ambiguidade, aponte-a em vez de adivinhar.\n- Use português claro e preserve a terminologia do material.\n- Para aprendizagem, conduza o raciocínio e ofereça feedback; não opere interfaces de avaliações nem envie respostas em nome do estudante.',
      `MATERIAL DE ESTUDO:\n<<<\n${material}\n>>>`,
      mode === 'review' ? `TENTATIVA DO ESTUDANTE:\n<<<\n${attempt}\n>>>` : ''
    ].filter(Boolean);
    lastPrompt = sections.join('\n\n');
    output.value = lastPrompt;
    result.classList.remove('wn-hidden');
    say('Pacote criado. Copie o prompt e cole na IA que preferir.');
  }

  async function copyText(text) {
    try {
      if (navigator.clipboard?.writeText && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        const temp = document.createElement('textarea');
        temp.value = text; temp.style.cssText = 'position:fixed;opacity:0;pointer-events:none;';
        shadow.appendChild(temp); temp.focus(); temp.select();
        const ok = document.execCommand('copy'); temp.remove();
        if (!ok) throw new Error('clipboard blocked');
      }
      say('Copiado para a área de transferência.');
    } catch (error) {
      output.focus(); output.select();
      say('A cópia automática foi bloqueada pelo navegador; use Copiar/Compartilhar no menu do dispositivo ou Ctrl+C.');
    }
  }
  function downloadPrompt() {
    if (!lastPrompt) { say('Gere um pacote primeiro.'); return; }
    try {
      const blob = new Blob([lastPrompt], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url; link.download = `waynovo-estudo-${new Date().toISOString().slice(0,10)}.txt`;
      shadow.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      say('Arquivo de estudo preparado.');
    } catch (error) { say('O navegador bloqueou o download; copie o prompt.'); }
  }
  function closePanel() { host.remove(); }

  source.addEventListener('input', updateCount);
  $('#wn-selection').addEventListener('click', captureSelection);
  $('#wn-page').addEventListener('click', captureVisiblePage);
  $('#wn-generate').addEventListener('click', buildPrompt);
  $('#wn-mode').addEventListener('change', () => $('#wn-attempt-wrap').classList.toggle('wn-hidden', $('#wn-mode').value !== 'review'));
  $('#wn-fast-tutor').addEventListener('click', () => { $('#wn-mode').value = 'tutor'; buildPrompt(); });
  $('#wn-fast-practice').addEventListener('click', () => { $('#wn-mode').value = 'practice'; buildPrompt(); });
  $('#wn-fast-cards').addEventListener('click', () => { $('#wn-mode').value = 'cards'; buildPrompt(); });
  $('#wn-copy').addEventListener('click', () => copyText(lastPrompt));
  $('#wn-download').addEventListener('click', downloadPrompt);
  $('#wn-clear').addEventListener('click', () => {
    source.value = ''; $('#wn-goal').value = ''; $('#wn-attempt').value = ''; output.value = '';
    lastPrompt = ''; result.classList.add('wn-hidden'); updateCount(); say('Conteúdo e resultado limpos.');
  });
  $('#wn-close').addEventListener('click', closePanel);
  $('#wn-close-bottom').addEventListener('click', closePanel);
  $('#wn-min').addEventListener('click', () => panel.classList.toggle('wn-min'));

  // Arrastar no desktop; mantém o comportamento normal de toque no celular.
  const dragHandle = $('#wn-drag');
  let dragging = false, dragX = 0, dragY = 0;
  dragHandle.addEventListener('pointerdown', (event) => {
    if (event.pointerType === 'touch' || event.target.closest('button') || window.matchMedia('(max-width:640px)').matches) return;
    dragging = true;
    const rect = panel.getBoundingClientRect();
    dragX = event.clientX - rect.left; dragY = event.clientY - rect.top;
    panel.style.left = `${rect.left}px`; panel.style.top = `${rect.top}px`;
    panel.style.right = 'auto'; panel.style.bottom = 'auto';
    dragHandle.setPointerCapture(event.pointerId);
  });
  dragHandle.addEventListener('pointermove', (event) => {
    if (!dragging) return;
    const left = Math.max(0, Math.min(window.innerWidth - panel.offsetWidth, event.clientX - dragX));
    const top = Math.max(0, Math.min(window.innerHeight - 64, event.clientY - dragY));
    panel.style.left = `${left}px`; panel.style.top = `${top}px`;
  });
  dragHandle.addEventListener('pointerup', () => { dragging = false; });
  dragHandle.addEventListener('pointercancel', () => { dragging = false; });

  source.value = initialSelection;
  updateCount();
  if (initialSelection) say('Seleção inicial capturada automaticamente.');
})();
